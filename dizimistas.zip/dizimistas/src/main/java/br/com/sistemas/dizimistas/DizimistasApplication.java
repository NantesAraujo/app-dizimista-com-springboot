package br.com.sistemas.dizimistas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DizimistasApplication {

	public static void main(String[] args) {
		SpringApplication.run(DizimistasApplication.class, args);
	}
}
